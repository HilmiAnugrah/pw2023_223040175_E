<section class="hero-bg z-index-0 pt-35 pb-20">
<div class="container">
    <div class="row gx-2 p-0">
        <div class="col-12 col-lg-12 col-xl-9 col-md-12 mb-2">
             <div id="hero" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner rounded-5">
                    <div class="carousel-item active"><a target="_blank" href="#">
                        <img src="img/hero/slide-1.png" alt="DTS 2023" class="d-block" style="width: 100%;"></a></div>
                            <div class="carousel-item"><a target="_blank" href="img/hero/slide-2.png">
                                <img src="img/hero/slide-2.png" alt="Talenttalks Season 1 2023" class="d-block" style="width: 100%;">
                            </a>
                            </div>
                        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#hero" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
                    </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#hero" data-bs-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="visually-hidden">Next</span>
                        </button>
                </div>
                </div>
                    <div class="col-12 col-lg-12 col-md-12 col-xl-3">
                        <div class="row gx-2">
                            <div class="col-6 col-lg-6 col-xl-12 mb-2 rounded-5 mb-2"><a target="_blank" href="https://www.youtube.com/playlist?list=PLqAc3Af_9k6yabQN57Qqx3_jzLq-RhP0K" width="100%"><img src="img/hero/side1.png" class="img-responsive rounded-5" width="100%"></a>
                                </div>
                                <div class="col-6 col-lg-6 col-xl-12 mb-2 rounded-5 "><a target="_blank" href="https://diploy.id/" width="100%"><img src="img/hero/side2.png" class="img-responsive rounded-5" width="100%"></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </section>




