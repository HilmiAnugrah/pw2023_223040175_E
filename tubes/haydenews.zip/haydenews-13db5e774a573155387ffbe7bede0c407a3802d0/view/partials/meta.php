<meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- seo -->
    <meta name="google-site-verification" content="Vnhm7VkI3_f-Eaba8aa_zu004LMN1q9j8dg01uPHfNY" />
    <meta name="url" content="https:/hilmianugrah.github.io/haydeberita/" />
    <meta name="description" content="Situs Berita Terbaru dan Terpercaya, Menyajikan Berita Terkini Dari Berbagai Sumber Berita" />
    <meta name="keywords" content="berita, terbaru, terkini, terpercaya, nasional, internasional, ekonomi, olahraga, hiburan, politik, hilmianugrah, haydeberita" />
    <meta name="description" content="Situs Berita Terbaru dan Terpercaya, Menyajikan Berita Terkini Dari Berbagai Sumber Berita" />
    <meta name="keywords" content="berita, terbaru, terkini, terpercaya, nasional, internasional, ekonomi, olahraga, hiburan, politik" />
    <meta name="robots" content="index,follow" />
    <meta name="canonical" content="https:/hilmianugrah.github.io/haydeberita/" />
    <meta name="author" content="Albasti" />
    <meta name="image" content="https://raw.githubusercontent.com/HilmiAnugrah/haydeberita/main/img/Link-sosmed.png" />
    <meta property="og:image" content="https://raw.githubusercontent.com/HilmiAnugrah/haydeberita/main/img/Link-sosmed.png" />
    <meta property="og:site_name" content="HaydeBerita" />
    <meta property="og:description" content="Situs Berita Terbaru dan Terpercaya, Menyajikan Berita Terkini Dari Berbagai Sumber Berita" />
    <meta property="og:url" content="https://hilmianugrah.github.io/haydeberita/" />
    <link rel="shortcut icon" href="favicon/favicon.ico" type="image/x-icon" />
