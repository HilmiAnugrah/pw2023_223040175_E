<head>
    <?php require "meta.php" ?>
  <?php require "mycss.php"; ?>
  </head>