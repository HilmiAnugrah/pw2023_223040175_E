<?php 
//card link
$link="index.php";
//card berita terkini
$berita = [
    [
        'imgSrc' => 'img/card-berita/masjid-aljabar.png',
        'judul' => 'Developer Wordpress',
        'tglPublish' => 'publish pada 11 mei 2023',
        'deskripsi' => 'Masjid Al Jabbar adalah salah satu masjid baru di Jawa Barat yang diresmikan pada Desember 2022. Masjid Al Jabbar berlokasi di Kota Bandung,..'
    ],
    [
        'imgSrc' => 'img/card-berita/masjid-aljabar.png',
        'judul' => 'Sukses Muda',
        'tglPublish' => 'publish pada 11 mei 2023',
        'deskripsi' => 'Masjid Al Jabbar adalah salah satu masjid baru di Jawa Barat yang diresmikan pada Desember 2022. Masjid Al Jabbar berlokasi di Kota Bandung,..'
    ],
    [
        'imgSrc' => 'img/card-berita/masjid-aljabar.png',
        'judul' => 'Masjid Al Jabar',
        'tglPublish' => 'publish pada 11 mei 2023',
        'deskripsi' => 'Masjid Al Jabbar adalah salah satu masjid baru di Jawa Barat yang diresmikan pada Desember 2022. Masjid Al Jabbar berlokasi di Kota Bandung,..'
    ],
    [
        'imgSrc' => 'img/card-berita/masjid-aljabar.png',
        'judul' => 'Kota Bandung',
        'tglPublish' => 'publish pada 11 mei 2023',
        'deskripsi' => 'Masjid Al Jabbar adalah salah satu masjid baru di Jawa Barat yang diresmikan pada Desember 2022. Masjid Al Jabbar berlokasi di Kota Bandung,..'
    ]
    
];
