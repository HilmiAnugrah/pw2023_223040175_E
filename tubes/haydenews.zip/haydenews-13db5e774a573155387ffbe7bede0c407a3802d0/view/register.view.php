
<!DOCTYPE html>
<html lang="en">
<head>
<title>Hayde news | Register</title>
    <link rel="stylesheet" href="logreg.css">
    <link rel="stylesheet" href="css/mybody.css">
    <link rel="stylesheet" href="css/cssreset.css">
    <?php require('partials/head.php'); ?>
</head>
<body>
    <?php 
require "partials/register.php";
    ?>
</body>
</html>