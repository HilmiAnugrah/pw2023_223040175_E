<section class="setting">
    <h1>halaman setting</h1>
</section>