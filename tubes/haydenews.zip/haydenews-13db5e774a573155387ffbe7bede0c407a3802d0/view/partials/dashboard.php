<section class="dashboard-section" >
    <h1>selamat datang <?= $username; ?></h1>
</section>