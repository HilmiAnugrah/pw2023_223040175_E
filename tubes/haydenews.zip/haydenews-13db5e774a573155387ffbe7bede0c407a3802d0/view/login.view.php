<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="logreg.css">
    <link rel="stylesheet" href="css/cssreset.css">
    <link rel="stylesheet" href="css/mybody.css">
    <?php require('partials/head.php'); ?>
    <title>Hayde news | Login</title>
</head>
<body>
    <?php require "partials/login.php"; ?>
</body>
</html>