    <?php 
      require('functions.php');
      require('beritaterkini.php');
    