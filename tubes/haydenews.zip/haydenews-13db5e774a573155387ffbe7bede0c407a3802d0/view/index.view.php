<!DOCTYPE html>
<html lang="en-id,US">
    <?php require('partials/head.php'); ?>
    <?php require('partials/header.php'); ?>
      <!-- popup menu -->
    <?php require("partials/popup.menu.php"); ?>
      <!-- akhir menu popup -->
      <!-- content  -->
    <?php require("partials/content.php"); ?>
      <!-- content  -->
<!-- footer -->
 <?php require("partials/footer.php"); ?>
<!-- akhir footer -->
